package com.example.flappybird;

public class GameOver {
    private int gameOverX, gameOverY;
//Constructor to initialize gameOver variables.
    public GameOver(){
        gameOverX = AppConstants.SCREEN_WIDTH/2 - AppConstants.getBitmapBank().getGameOverWidth()/2;
        gameOverY = AppConstants.SCREEN_HEIGHT/2-AppConstants.getBitmapBank().getGameOverHeight()/2;

    }


    public int getX(){
        return gameOverX;
    }
    //Getter method for getting the Y-coordinate of the bird
    public int getY(){
        return gameOverY;
    }
    // Setter method for setting the X-coordinate
    public void setX(int gameOverX){
        this.gameOverX=gameOverX;
    }
    //Setter method for setting the Y-coordinate
    public void setY(int gameOverY){
        this.gameOverY = gameOverY;
    }
}
