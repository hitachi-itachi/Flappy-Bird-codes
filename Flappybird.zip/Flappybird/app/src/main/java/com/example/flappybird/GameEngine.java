package com.example.flappybird;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

public class GameEngine {
    BitmapBank bitmapBank;
    BackgroundImage backgroundImage;
    Bird bird;
    GameOver gameover;
    Pipe bottomPipe;
    Paint Paint;
    UpperPipe upperPipe;
    static int gameState;
    int counter = 0;
    int gameCount = 0;


    public GameEngine() {
        backgroundImage = new BackgroundImage();
        bird = new Bird();
        gameover = new GameOver();
        bottomPipe = new Pipe();
        Paint = new Paint();
        upperPipe = new UpperPipe();
        // 0= Not Started
        //1= Playing
        //2=Game Over
        gameState = 0;
        Rect r1 = new Rect();
        Rect r2 = new Rect();


    }

    public void reset()
    {
        if (gameState == 3){

            backgroundImage.setX(0);
        backgroundImage.setY(0);
        bottomPipe.setX(AppConstants.SCREEN_WIDTH);
        bottomPipe.setY(AppConstants.SCREEN_HEIGHT/2);
        upperPipe.setX(AppConstants.SCREEN_WIDTH);
        upperPipe.setY(AppConstants.SCREEN_HEIGHT/2-1500);
        bird.setY(AppConstants.SCREEN_HEIGHT/2-AppConstants.getBitmapBank().getBirdHeight()/2);
        bird.setX(AppConstants.SCREEN_WIDTH/2 - AppConstants.getBitmapBank().getBirdWidth()/2);
        gameCount=0;

    }

}

    public void updateandDrawBackground(Canvas canvas) {
        backgroundImage.setX(backgroundImage.getX() - backgroundImage.getVelocity());
        if (backgroundImage.getX() < -AppConstants.getBitmapBank().getBackgroundWidth()) {
            backgroundImage.setX(0);
        }
        canvas.drawBitmap(AppConstants.getBitmapBank().getBackground(), backgroundImage.getX(), backgroundImage.getY(), null);
        if (backgroundImage.getX() < -(AppConstants.getBitmapBank().getBackgroundWidth() - AppConstants.SCREEN_WIDTH)) {
            canvas.drawBitmap(AppConstants.getBitmapBank().getBackground(), backgroundImage.getX() + AppConstants.getBitmapBank().getBackgroundWidth(), backgroundImage.getY(), null);
        }
    }


    public void updateAndDrawGameOver(Canvas canvas) {
        if (bird.getY() > (AppConstants.SCREEN_HEIGHT - AppConstants.getBitmapBank().getBirdHeight()) && gameState==2 || gameState==4) {
            gameState=4;
        }
        else if (bird.getY() > (AppConstants.SCREEN_HEIGHT - AppConstants.getBitmapBank().getBirdHeight()) && gameState!=2 && gameState!=4 && gameState!=3) {
            gameState=2;
        }


    }


    public void updateAndDrawBird(Canvas canvas) {
        if (gameState == 1) {
            if (bird.getY() < (AppConstants.SCREEN_HEIGHT - AppConstants.getBitmapBank().getBirdHeight()) || bird.getVelocity() < 0) {
                bird.setVelocity(bird.getVelocity() + AppConstants.gravity);
                bird.setY(bird.getY() + bird.getVelocity());
                counter++;
            }

        }


        int currentFrame = bird.getCurrentFrame();
        canvas.drawBitmap(AppConstants.getBitmapBank().getBird(currentFrame), bird.getX(), bird.getY(), null);
        currentFrame++;
        //If it exceeds maxFrame re-initialize  to 0
        if (currentFrame > bird.maxFrame) {
            currentFrame = 0;
        }
        bird.setCurrentFrame(currentFrame);


    }
    public int updateAndDrawBirdCoordinate() {
                return bird.getY();

    }

    public void updateAndBottomPipe(Canvas canvas) {
        if (gameState == 1) {
            do {
                bottomPipe.setX(bottomPipe.getX() - bottomPipe.getVelocity());
                if (bottomPipe.getX() < -AppConstants.getBitmapBank().getBottomPipeWidth()) {
                    bottomPipe.setX(AppConstants.SCREEN_WIDTH);

                }

                canvas.drawBitmap(AppConstants.getBitmapBank().getBottomPipe(), bottomPipe.getX(), bottomPipe.getY(), null);
                counter = 0;
            } while (counter == 100);

        }
    }
    public void updateAndUpperPipe(Canvas canvas) {
        if (gameState == 1) {
            do {
                upperPipe.setX(upperPipe.getX() - upperPipe.getVelocity());
                if (upperPipe.getX() < -AppConstants.getBitmapBank().getUpperPipeWidth()) {
                   upperPipe.setX(AppConstants.SCREEN_WIDTH);

                }

                canvas.drawBitmap(AppConstants.getBitmapBank().getUpperPipe(), upperPipe.getX(), upperPipe.getY(), null);
                counter = 0;
            } while (counter == 100);

        }
    }
    public int updateWidth(){
        return AppConstants.getBitmapBank().getBottomPipeWidth() - 3;

    }

    public int updateAndBottomPipeCoordinates() {

            return bottomPipe.getX();


    }
    public int updateAndUpperPipeCoordinates() {

        return upperPipe.getX();


    }



    public void getflappyCollide(Canvas canvas) {
        ;
        if (gameState == 1) {
           Rect r1 = new Rect(AppConstants.getBitmapBank().getBirdWidth() + 200, updateAndDrawBirdCoordinate(), bird.getX() + 100, updateAndDrawBirdCoordinate() + 200);
           Rect r2 = new Rect(updateAndBottomPipeCoordinates() - 50, bottomPipe.getY(), AppConstants.getBitmapBank().getBottomPipeWidth() + 300, AppConstants.getBitmapBank().getBottomPipeHeight() + 1000);
            Rect r3 = new Rect((updateAndUpperPipeCoordinates() - 50), upperPipe.getY() - 50, AppConstants.getBitmapBank().getUpperPipeWidth() + 300, AppConstants.getBitmapBank().getUpperHeight() - 150);
               if((r2.left-r2.right)>=200) {
                   // r1 = new Rect(AppConstants.getBitmapBank().getBirdWidth() + 40, AppConstants.getBitmapBank().getBirdHeight() - 200, bird.getX()+50, updateAndDrawBirdCoordinate() + 100);
                   r1 = new Rect(AppConstants.getBitmapBank().getBirdWidth() + 200, updateAndDrawBirdCoordinate(), bird.getX() + 100, updateAndDrawBirdCoordinate() + 200);
                   r2 = new Rect(updateAndBottomPipeCoordinates() - 50, bottomPipe.getY(), AppConstants.getBitmapBank().getBottomPipeWidth() + 250, AppConstants.getBitmapBank().getBottomPipeHeight() + 1000);
                   r3 = new Rect((updateAndUpperPipeCoordinates() - 50), upperPipe.getY() - 50, AppConstants.getBitmapBank().getUpperPipeWidth() + 300, AppConstants.getBitmapBank().getUpperHeight() - 150);
                   // r3=new Rect((updateAndUpperPipeCoordinates()-50), upperPipe.getY()+200, AppConstants.getBitmapBank().getUpperPipeWidth()+300, AppConstants.getBitmapBank().getUpperHeight()-200);
                   //r2 = new Rect( AppConstants.getBitmapBank().getBottomPipeWidth(), bottomPipe.getY(), updateAndBottomPipeCoordinates(), AppConstants.getBitmapBank().getBottomPipeHeight() + 300);
                   //r3=new Rect((updateAndUpperPipeCoordinates()-50), upperPipe.getY()+200, AppConstants.getBitmapBank().getUpperPipeWidth()+300, AppConstants.getBitmapBank().getUpperHeight()-200);



               }
               else{
                   r2=new Rect(0,0,0,0);
                   r3=new Rect(0,0,0,0);
               }
            //canvas.drawRect(r1, Paint);
            //canvas.drawRect(r2, Paint);
            //canvas.drawRect(r3, Paint);


            if (Rect.intersects(r2, r1) || Rect.intersects(r3,r1)) {
              gameState=2;
            }

        }
    }

    public void updateAndBottomPipeCoordinates2() {
Rect r2=new Rect(Math.abs(updateAndBottomPipeCoordinates()-100), Math.abs(bottomPipe.getY()),Math.abs(AppConstants.getBitmapBank().getBottomPipeWidth()+100), AppConstants.getBitmapBank().getBottomPipeHeight()+300);
        System.out.println(r2.left);


    }
    public int updateGameCounter() {
        Rect r2 = new Rect(Math.abs(updateAndBottomPipeCoordinates() - 100), Math.abs(bottomPipe.getY()), Math.abs(AppConstants.getBitmapBank().getBottomPipeWidth() + 100), AppConstants.getBitmapBank().getBottomPipeHeight() + 300);
        if (gameState == 1) {
            if (r2.left == 350) {
                gameCount++;
            }
            System.out.println(gameCount);
        }
        return gameCount;
    }
    public void updateCover(Canvas canvas, Paint paint,int gameCount) {
        Rect r2 = new Rect(Math.abs(updateAndBottomPipeCoordinates() - 100), Math.abs(bottomPipe.getY()), Math.abs(AppConstants.getBitmapBank().getBottomPipeWidth() + 100), AppConstants.getBitmapBank().getBottomPipeHeight() + 300);
        Rect r = new Rect();
            canvas.getClipBounds(r);
            int cHeight = r.height();
            int cWidth = r.width();
            paint.setTextAlign(android.graphics.Paint.Align.LEFT);
            paint.getTextBounds(String.valueOf(updateGameCounter()), 0, updateGameCounter(), r);
            float x = cWidth / 2f - r.width() / 2f - r.left;
            float y = cHeight / 2f + r.height() / 2f - r.bottom;

        if (gameState == 1) {
            if (r2.left == 350) {
                gameCount++;
            }
            System.out.println(gameCount);
            canvas.drawText(String.valueOf(gameCount), x, y, paint);
        }
    }

    public void drawGameOver(Canvas canvas){
        if(gameState==2 || gameState==4){
            canvas.drawBitmap(AppConstants.getBitmapBank().getGameOver(), gameover.getX(), gameover.getY(), null);
        }


    }
    public void printGameState(){
        System.out.println("GameState"+gameState);
    }


}

