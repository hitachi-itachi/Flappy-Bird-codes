package com.example.flappybird;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

//declare object reference for the background
public class BitmapBank {

    Bitmap background2;
    Bitmap[] bird;
    Bitmap gameOver;
    Bitmap bottomPipe;
    Bitmap upperPipe;

    public BitmapBank(Resources res) {
        background2= BitmapFactory.decodeResource(res, R.drawable.background2);
        background2 = scaleImage(background2);
        bird = new Bitmap[3];
        bird[0]= BitmapFactory.decodeResource(res, R.drawable.flappybird1);
        bird[1]= BitmapFactory.decodeResource(res, R.drawable.flappybird2);
        bird[2]= BitmapFactory.decodeResource(res, R.drawable.flappybird3);
        gameOver= BitmapFactory.decodeResource(res, R.drawable.game_over);
        bottomPipe=BitmapFactory.decodeResource(res,R.drawable.bottom_pipe);
        upperPipe=BitmapFactory.decodeResource(res,R.drawable.top_pipe);



}
//Return bird bitmap of frame
    public Bitmap getBird(int frame){
        return bird[frame];
    }
    public int getBirdWidth(){

        return bird[0].getWidth();
    }
    public int getBirdHeight() {
        return bird[0].getHeight();

    }

    public Bitmap getBottomPipe(){
        return bottomPipe;
    }

    public int getBottomPipeWidth(){

        return bottomPipe.getWidth();
    }
    public int getBottomPipeHeight() {
        return bottomPipe.getHeight();

    }
    public Bitmap getGameOver(){
        return gameOver;
    }
    public int getGameOverWidth(){

        return gameOver.getWidth();
    }
    public int getGameOverHeight() {
        return gameOver.getHeight();

    }



    public Bitmap getUpperPipe(){
        return upperPipe;
    }

    public int getUpperPipeWidth(){

        return upperPipe.getWidth();
    }
    public int getUpperHeight() {
        return upperPipe.getHeight();

    }


//Return background bitmap
    public Bitmap getBackground(){
        return background2;
    }
    //return background width
    public int getBackgroundWidth(){
        return background2.getWidth();
    }
    //Return background height
    public int getBackgroundHeight(){
        return background2.getHeight();
    }
    public Bitmap scaleImage(Bitmap bitmap){
        float widthHeightRatio = getBackgroundWidth() / getBackgroundHeight();
        /*
        We'll multiply widthHeightRatio with screenHeight to get scaled width of the Bitmap
        Then call createScaledBitmap() to create a new bitmap, scaled from an existing bitmap, when possible.
         */
        int backgroundScaleWidth = (int) widthHeightRatio * AppConstants.SCREEN_HEIGHT;
      return Bitmap.createScaledBitmap(bitmap, backgroundScaleWidth, AppConstants.SCREEN_HEIGHT, false);


}
}