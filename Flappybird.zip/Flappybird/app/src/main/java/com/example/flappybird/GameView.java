package com.example.flappybird;

import android.content.Context;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameView extends SurfaceView implements SurfaceHolder.Callback{
    Bird bird;
    Pipe bottomPipe;
    GameThread gameThread;
    BackgroundImage backgroundImage;
    MainActivity mainActivity;

    public GameView(Context context) {
        super(context);
        initView();
        bird =new Bird();
        bottomPipe=new Pipe();
        backgroundImage= new BackgroundImage();
        mainActivity=new MainActivity();
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if(!gameThread.isRunning()) {
            gameThread = new GameThread(holder);
            gameThread.start();
        }else{
            gameThread.start();
        }

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
         if(gameThread.isRunning()){
             gameThread.setIsRunning(false);
             boolean retry=true;
             while(retry){
                 try {
                     gameThread.join();
                     retry = false;
                 }catch(InterruptedException e){}
             }
         }
    }
    void initView(){
        SurfaceHolder holder=getHolder();
        holder.addCallback(this);
        setFocusable(true);
        gameThread=new GameThread(holder);
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();
        //Tap is detected

        if(AppConstants.getGameEngine().gameState==2 && action==MotionEvent.ACTION_DOWN) {
                AppConstants.getGameEngine().gameState=3;
        }
        else if(AppConstants.getGameEngine().gameState==1 && action== MotionEvent.ACTION_DOWN){
            AppConstants.getGameEngine().bird.setVelocity(AppConstants.VELOCITY_WHEN_JUMPED);
        }
        else if(action== MotionEvent.ACTION_DOWN && AppConstants.getGameEngine().gameState==0){
            AppConstants.getGameEngine().gameState=1;
            AppConstants.getGameEngine().bird.setVelocity(AppConstants.VELOCITY_WHEN_JUMPED);
        }
        else if(AppConstants.getGameEngine().gameState==3 && action==MotionEvent.ACTION_DOWN){
            AppConstants.getGameEngine().gameState=0;
        }
        else if((AppConstants.getGameEngine().gameState==4 && action==MotionEvent.ACTION_DOWN)){
            AppConstants.getGameEngine().gameState=3;
        }



        return true;
    }

}
