package com.example.flappybird;

public class UpperPipe {
    private int PipeX, PipeY, PipeVelocity;
    public UpperPipe(){
        PipeX =AppConstants.SCREEN_WIDTH;
        PipeY=AppConstants.SCREEN_HEIGHT/2-1500;
        PipeVelocity = 3;
}
    //Getter method for getting the X-coordinate
    public int getX(){
        return  PipeX;
    }
    //Getter method for getting the Y-coordinate
    public int getY(){
        return PipeY;
    }
    //setter method for setting the X-coordinate
    public void setX(int PipeX){
        this.PipeX = PipeX;
    }
    // Setter method for setting the Y-coordinate
    public void setY(int PipeY){
        this.PipeY=PipeY;
    }
    //Getter method for getting the velocity
    public int getVelocity() {
        return PipeVelocity;
    }
}