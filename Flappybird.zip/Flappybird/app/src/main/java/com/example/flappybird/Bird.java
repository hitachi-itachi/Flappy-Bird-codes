package com.example.flappybird;

import android.content.Context;

public class Bird {
    private int birdX, birdY, coordinateY,currentFrame,velocity;
    public static int maxFrame;

    public Bird(){
        birdX = AppConstants.SCREEN_WIDTH/2 - AppConstants.getBitmapBank().getBirdWidth()/2;
        birdY = AppConstants.SCREEN_HEIGHT/2-AppConstants.getBitmapBank().getBirdHeight()/2;
        currentFrame = 0;
        maxFrame = 2;
        velocity=0;
    }
    //Getter method for getting X-coordinate of the Bird
    public int getCurrentFrame(){
        return currentFrame;
    }
    //Getter method for getting the Y-coordinate of the Bird
    public void setCurrentFrame(int currentFrame){
        this.currentFrame = currentFrame;
    }

//Getter method for velocity
    public int getVelocity(){
        return velocity;
    }
    //Setter method for velocity
    public void setVelocity(int velocity){
        this.velocity=velocity;
    }
    public int getX(){
        return birdX;
    }
    //Getter method for getting the Y-coordinate of the bird
    public int getY(){
        return birdY;
    }
    // Setter method for setting the X-coordinate
    public void setX(int birdX){
        this.birdX=birdX;
    }
    //Setter method for setting the Y-coordinate
    public void setY(int birdY){
        this.birdY = birdY;
    }

    public int getCoordinateY(){
        return coordinateY;
    }
    public void setCoordinateY(){
        this.coordinateY=coordinateY;
    }





}

