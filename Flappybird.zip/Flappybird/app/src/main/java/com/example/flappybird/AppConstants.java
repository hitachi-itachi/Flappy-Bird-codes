package com.example.flappybird;

import android.content.Context;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

public class AppConstants {
    static BitmapBank bitmapBank;// Bitmap object reference
    static GameEngine gameEngine;// GameEngine object reference
    static int SCREEN_WIDTH, SCREEN_HEIGHT;
    static int gravity;
    static int VELOCITY_WHEN_JUMPED;
    static GameOver gameover;
     static Pipe Pipe;
     static UpperPipe upperPipe;
    static Bird bird;
    static BackgroundImage backgroundImage;
    static GameThread gameThread;


    public static void initialization(Context context) {
        setScreenSize(context);
        bitmapBank = new BitmapBank(context.getResources());
        gameEngine = new GameEngine();
        gameover = new GameOver();
        upperPipe=new UpperPipe();
        Pipe= new Pipe();
        bird=new Bird();
        backgroundImage = new BackgroundImage();
        gravity = 3;
        AppConstants.VELOCITY_WHEN_JUMPED = -40;


    }

    //Return BitmapBank instance
    public static BitmapBank getBitmapBank() {
        return bitmapBank;
    }

    // Return GameEngine Instance
    public static GameEngine getGameEngine() {
        return gameEngine;
    }
    public static GameThread getGameThread() {
        return gameThread;
    }


    public static void getPosition() {

        System.out.println(backgroundImage.getX());
    }
    public static void setZero(){
        if (Pipe.getX() < -AppConstants.getBitmapBank().getBackgroundWidth()) {
            gameEngine.updateAndBottomPipeCoordinates();
        }
    }


    private static void setScreenSize(Context context){
        WindowManager wm= (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display= wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        AppConstants.SCREEN_WIDTH=width;
        AppConstants.SCREEN_HEIGHT=height;
    }


}
